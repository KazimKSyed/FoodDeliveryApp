export class User {
    constructor(){}
    id:number;
    firstName:string;
    lastName:string;
    contactNumber:number;
    email:string;
    password:string;
    confirmPassword:string
 
 }
